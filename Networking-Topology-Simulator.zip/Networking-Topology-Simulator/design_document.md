# Cisco VIP 2025 – Networking Tool: Complete Implementation Design

> Goal: From a directory of router/switch configs, auto‑generate a hierarchical network topology, validate & optimize configs, analyze capacity vs. load, and simulate Day‑1/Day‑2 behavior with fault injection using multithreading + IPC.

## 1) End‑to‑End Architecture
(omitted diagram in markdown)
- Config Input → Parsing Engine → Network Model → Topology Builder
- Validator/Rules + Capacity & LB → Suggestions
- Simulation Engine (Threads+IPC) → Visualization, Reports, Logs

## 2) Data Model
- Device, Interface, Link, VLAN, Routing(OSPF/BGP), Endpoint, Topology (see src/netgen/model/*).

## 3) Parsing Engine
- TextFSM/regex templates for IOS‑like configs.
- Extract: hostname, interfaces, IPs, VLANs, MTU, OSPF/BGP, LLDP/CDP neighbors.

## 4) Topology Inference
- Prefer CDP/LLDP, fall back to L3 same-subnet, then routing neighbors.
- Role assignment via k‑core + link speed heuristics.

## 5) Validation Rules
- Duplicate IP, wrong gateway, VLAN label mismatch/trunking gaps, MTU mismatches, L2 loops, protocol recommendations, aggregation/ECMP.

## 6) Capacity & Load
- Compute per‑link utilization from traffic matrix; recommend LB/ECMP and QoS hints.

## 7) Simulation (Threads + IPC)
- Device thread per node; simple metadata packet types; Day‑1 OSPF hello; link‑down events; pause/resume.

## 8) Outputs
- Interactive topology (PyVis), JSON artifacts, HTML reports (optional).

## 9) CLI
- `parse`, `topo`, `validate`, `plan`, `simulate`, `inject`, `pause`, `resume` (stubs implemented for first five).

## 10) Testing
- Unit tests for parsers and IP math (skeleton).

## 11) MVP
- Build graph, basic validation, simple capacity planner, stub simulation.
