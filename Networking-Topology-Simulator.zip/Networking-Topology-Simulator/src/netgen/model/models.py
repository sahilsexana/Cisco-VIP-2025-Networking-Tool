from pydantic import BaseModel, Field
from typing import List, Optional, Dict

class Interface(BaseModel):
    name: str
    ipv4: Optional[str] = None
    mtu: Optional[int] = None
    speed_mbps: Optional[int] = None
    vlan: Optional[int] = None
    description: Optional[str] = None

class RoutingOSPF(BaseModel):
    process_id: Optional[str] = None
    areas: List[str] = []

class RoutingBGP(BaseModel):
    asn: Optional[int] = None
    neighbors: List[str] = []

class Device(BaseModel):
    name: str
    role: Optional[str] = None
    interfaces: List[Interface] = []
    vlans: Dict[int, str] = {}
    ospf: Optional[RoutingOSPF] = None
    bgp: Optional[RoutingBGP] = None
    neighbors: Dict[str, str] = {}  # local_intf -> "PEER:peer_intf"

class Link(BaseModel):
    a_device: str
    a_intf: str
    b_device: str
    b_intf: str
    bandwidth_mbps: int = 1000
    mtu: Optional[int] = None
