from typing import Dict
import time, json, os

def simulate_day1(topology_json: str, out_dir: str) -> None:
    os.makedirs(out_dir, exist_ok=True)
    trace = [
        {'t':0, 'event':'power_on_all'},
        {'t':2, 'event':'ospf_hello_exchange', 'result':'neighbors_partial'},
        {'t':5, 'event':'ospf_full', 'result':'adjacencies_full'}
    ]
    with open(os.path.join(out_dir, 'simulation_trace.jsonl'), 'w', encoding='utf-8') as f:
        for e in trace:
            f.write(json.dumps(e) + "\n")
