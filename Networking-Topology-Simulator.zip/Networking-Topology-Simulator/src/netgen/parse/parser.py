import re, os, glob
from typing import List, Dict
from netgen.model.models import Device, Interface, RoutingOSPF

HOST_RE = re.compile(r'^hostname\s+(?P<name>\S+)', re.M)
INTF_START = re.compile(r'^interface\s+(?P<intf>\S+)', re.M)
IP_RE = re.compile(r'^\s+ip address\s+(?P<ip>\d+\.\d+\.\d+\.\d+)\s+(?P<mask>\d+\.\d+\.\d+\.\d+)', re.M)
MTU_RE = re.compile(r'^\s+mtu\s+(?P<mtu>\d+)', re.M)
VLAN_RE = re.compile(r'^vlan\s+(?P<vlan>\d+)', re.M)
VLAN_NAME_RE = re.compile(r'^\s+name\s+(?P<name>\S+)', re.M)
OSPF_START = re.compile(r'^router ospf\s+(?P<pid>\S+)', re.M)
NEI_RE = re.compile(r'^!\s+NEIGHBOR:\s+(?P<lintf>\S+)\s+->\s+(?P<peer>\S+):(?P<pintf>\S+)', re.M)

def parse_config(path: str) -> Device:
    with open(path, 'r', encoding='utf-8') as f:
        text = f.read()

    m = HOST_RE.search(text)
    name = m.group('name') if m else os.path.basename(os.path.dirname(path))
    dev = Device(name=name, interfaces=[], vlans={}, neighbors={})

    # Interfaces (naive block scan)
    for m in INTF_START.finditer(text):
        intf = m.group('intf')
        # Extract sub-block for interface
        start = m.end()
        next_m = INTF_START.search(text, start)
        block = text[start: next_m.start()] if next_m else text[start:]
        ipm = IP_RE.search(block)
        mtum = MTU_RE.search(block)
        iface = Interface(name=intf)
        if ipm:
            iface.ipv4 = f"{ipm.group('ip')}/{mask_to_prefix(ipm.group('mask'))}"
        if mtum:
            iface.mtu = int(mtum.group('mtu'))
        dev.interfaces.append(iface)

    # VLANs
    for m in VLAN_RE.finditer(text):
        vid = int(m.group('vlan'))
        # find name immediately after
        n = VLAN_NAME_RE.search(text, m.end(), m.end()+60)
        dev.vlans[vid] = n.group('name') if n else f"VLAN{vid}"

    # OSPF
    om = OSPF_START.search(text)
    if om:
        dev.ospf = RoutingOSPF(process_id=om.group('pid'), areas=['0'])

    # Neighbor hints
    for nm in NEI_RE.finditer(text):
        lintf = nm.group('lintf')
        dev.neighbors[lintf] = f"{nm.group('peer')}:{nm.group('pintf')}"

    return dev

def mask_to_prefix(mask: str) -> int:
    return sum(bin(int(o)).count('1') for o in mask.split('.'))

def parse_dir(conf_dir: str) -> List[Device]:
    devices = []
    for cfg in glob.glob(os.path.join(conf_dir, '**', 'config.dump'), recursive=True):
        devices.append(parse_config(cfg))
    return devices
