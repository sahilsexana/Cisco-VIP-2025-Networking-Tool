from typing import List, Dict
from netgen.model.models import Device, Link
import ipaddress

def validate_basic(devices: List[Device], links: List[Link]) -> Dict:
    findings = {'duplicate_ips':[], 'mtu_mismatches':[]}
    # Duplicate IPs (within same /24 naive grouping)
    seen = {}
    for d in devices:
        for i in d.interfaces:
            if not i.ipv4: continue
            ip = i.ipv4.split('/')[0]
            if ip in seen:
                findings['duplicate_ips'].append({'ip': ip, 'ifs': [seen[ip], f"{d.name}:{i.name}"]})
            else:
                seen[ip] = f"{d.name}:{i.name}"
    # MTU mismatches (edge-wise, naive: compare stored MTU if both present)
    for l in links:
        left = next((i for d in devices if d.name==l.a_device for i in d.interfaces if i.name==l.a_intf), None)
        right = next((i for d in devices if d.name==l.b_device for i in d.interfaces if i.name==l.b_intf), None)
        if left and right and left.mtu and right.mtu and left.mtu != right.mtu:
            findings['mtu_mismatches'].append({'link': f"{l.a_device}:{l.a_intf}-{l.b_device}:{l.b_intf}", 'a': left.mtu, 'b': right.mtu})
    return findings
