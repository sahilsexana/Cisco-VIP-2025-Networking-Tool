class Channel:
    def __init__(self, name: str):
        self.name = name
    def send(self, msg: dict):
        pass
    def recv(self) -> dict:
        return {}
