from typing import List, Dict, Tuple
from netgen.model.models import Device, Link
import networkx as nx

def build_links(devices: List[Device]) -> List[Link]:
    # Use neighbor hints to create links
    links: Dict[Tuple[str,str,str,str], Link] = {}
    name_map = {d.name: d for d in devices}
    for d in devices:
        for lintf, peer in d.neighbors.items():
            peer_dev, peer_intf = peer.split(':', 1)
            key = tuple(sorted([(d.name, lintf), (peer_dev, peer_intf)]))
            if key in links: 
                continue
            # attempt MTU from local interface
            mtu = None
            for i in d.interfaces:
                if i.name == lintf: mtu = i.mtu
            links[key] = Link(a_device=d.name, a_intf=lintf, b_device=peer_dev, b_intf=peer_intf, mtu=mtu or 1500)
    return list(links.values())

def to_graph(devices: List[Device], links: List[Link]) -> nx.Graph:
    g = nx.Graph()
    for d in devices:
        g.add_node(d.name, role=d.role or 'unknown')
    for l in links:
        g.add_edge(l.a_device, l.b_device, mtu=l.mtu, bandwidth=l.bandwidth_mbps)
    return g

def assign_roles(g: nx.Graph) -> None:
    import math
    kcore = nx.core_number(g) if g.number_of_nodes() > 0 else {}
    # Simple heuristic
    for n in g.nodes:
        k = kcore.get(n, 0)
        if k >= 2: g.nodes[n]['role'] = 'core'
        elif k == 1: g.nodes[n]['role'] = 'distribution'
        else: g.nodes[n]['role'] = 'access'
