from pyvis.network import Network
import networkx as nx

def export_pyvis(g: nx.Graph, out_html: str) -> None:
    net = Network(height='750px', width='100%', directed=False)
    for n, data in g.nodes(data=True):
        role = data.get('role','unknown')
        size = {'core':35,'distribution':25,'access':18}.get(role,15)
        net.add_node(n, label=f"{n}\n({role})", title=role, value=size)
    for u,v,data in g.edges(data=True):
        label = f"{data.get('bandwidth', '')} Mbps / MTU {data.get('mtu','')}"
        net.add_edge(u, v, title=label, label=label)
    net.show(out_html)
