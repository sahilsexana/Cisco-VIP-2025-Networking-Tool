import json, typer, os
from typing import Optional
from rich import print
from netgen.parse.parser import parse_dir
from netgen.topo.topology import build_links, to_graph, assign_roles
from netgen.topo.viz import export_pyvis
from netgen.validate.validator import validate_basic
from netgen.plan.planner import plan_capacity

app = typer.Typer(add_completion=False, no_args_is_help=True)

@app.command()
def parse(conf_dir: str, out: str = typer.Option('build/parsed.json', help='Output JSON path')):
    devices = parse_dir(conf_dir)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump([d.model_dump() for d in devices], f, indent=2)
    print(f"[green]Parsed {len(devices)} devices -> {out}[/green]")

@app.command()
def topo(parsed: str, viz: Optional[str] = typer.Option(None, help='Output HTML for topology'),
         out: str = typer.Option('build/topology.json')):
    with open(parsed, 'r', encoding='utf-8') as f:
        devices_dicts = json.load(f)
    # pydantic model reconstruction
    from netgen.model.models import Device, Link
    devices = [Device(**d) for d in devices_dicts]
    links = build_links(devices)
    g = to_graph(devices, links)
    assign_roles(g)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    topo_json = {'devices': [d.model_dump() for d in devices], 'links': [l.model_dump() for l in links]}
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(topo_json, f, indent=2)
    print(f"[green]Topology built with {len(devices)} devices and {len(links)} links -> {out}[/green]")
    if viz:
        export_pyvis(g, viz)
        print(f"[cyan]Interactive topology: {viz}[/cyan]")

@app.command()
def validate(parsed: str, policy: str = typer.Option('policy/policy.yaml'), out: str = typer.Option('build/findings.json')):
    import yaml
    with open(parsed, 'r', encoding='utf-8') as f:
        devices_dicts = json.load(f)
    from netgen.model.models import Device, Link
    devices = [Device(**d) for d in devices_dicts]
    # Rebuild links for validation context
    links = build_links(devices)
    findings = validate_basic(devices, links)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(findings, f, indent=2)
    print(f"[yellow]Validation findings -> {out}[/yellow]")

@app.command()
def plan(topology: str, traffic: str, out: str = typer.Option('build/plan.json')):
    with open(topology, 'r', encoding='utf-8') as f:
        topo = json.load(f)
    from netgen.model.models import Link
    links = [Link(**l) for l in topo['links']]
    plan = plan_capacity(links, traffic)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(plan, f, indent=2)
    print(f"[blue]Capacity plan -> {out}[/blue]")

@app.command()
def simulate(topology: str, events: str, out: str = typer.Option('build/sim')):
    from netgen.sim.sim import simulate_day1
    simulate_day1(topology, out)
    print(f"[magenta]Simulation stub executed -> {out}[/magenta]")

if __name__ == '__main__':
    app()
