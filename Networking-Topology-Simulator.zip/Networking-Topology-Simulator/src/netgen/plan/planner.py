from typing import Dict, List
from netgen.model.models import Device, Link
import yaml

def plan_capacity(links: List[Link], traffic_yaml: str) -> Dict:
    with open(traffic_yaml, 'r', encoding='utf-8') as f:
        profile = yaml.safe_load(f) or {}
    # Stub: mark links with peak > 80% bandwidth as risky (no real routing considered here)
    out = {'links': []}
    for l in links:
        peak = 100  # pretend 100 Mbps peak per VLAN as placeholder
        util = peak / max(l.bandwidth_mbps, 1)
        out['links'].append({'link': f"{l.a_device}-{l.b_device}", 'bandwidth': l.bandwidth_mbps, 'peak_assumed': peak, 'utilization': round(util,2)})
    return out
